# esim1 Luokka ja olio

Tässä esimerkissä tutustutaan käistteisiin **luokka ja olio**.

Yleensä C++ koodia ei kirjoiteta tällä tavalla yhteen tiedostoon kuin tässä esimerkissä.

Esimerkissä olen luonut Person-luokan main.cpp tiedostossa. Yleensä jokaiselle luokalle luodaan kaksi omaa tiedostoa. Person-luokalle luotaisiin tiedostot **person.h** ja **person.cpp**

Esimerkissä on luotu Person luokasta kaksi oliota eri tavalla. 

objectPerson1 on luotu pinomuistiin ja se on siis ns. automaattinen olio.

objectPerson2 on luotu dynaamiseen muistiin eli kekomuistiin. Sen tuhoamisesta ja muistivarauksesta on huolehdittava.

